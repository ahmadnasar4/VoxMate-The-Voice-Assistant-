def conversation():
    responses = ["I'm here to help!",
                 "How can I assist you today?",
                 "Ready for your command!"]
    import random
    return random.choice(responses)
